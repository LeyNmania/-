
App({
  globalData: {
    SGIndex:0,
    index:0,
    temp:[]
  },
  
})  