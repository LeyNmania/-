Page({
  onTap: function (event) {
    wx.switchTab({
      url: '../general/general',
    })

  },
  onShareAppMessage: function (res) {
    var that = this;
    return {
      title: '',
      path: '/pages/welcome/welcome',
      success: function (res) {
        // 转发成功  

        that.shareClick();
      },
      fail: function (res) {
        // 转发失败  
      }
    }
  },  
})