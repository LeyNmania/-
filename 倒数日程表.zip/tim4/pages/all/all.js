
Page({
  data: {
    array: [],
    flag: 0,
    index:0

  },
  onLoad: function (event) {
    var temp1 = [];
    var flag = 0;
    var that = this;
    

    if (!wx.getStorageSync('sg')) {
      var array = [];
      that.setData({
        'array': array
      })
    }
    else {
      temp1.push(wx.getStorageSync('sg'));
      that.setData({
        array: temp1[0]
      })
    }
    flag = 1;
    this.setData({
      'flag': flag
    })
  },

  onPullDownRefresh() {
    var that = this;
    this.onLoad();
    if (that.data.flag) {
      wx.stopPullDownRefresh();
    }
  },

  onShareAppMessage: function (res) {
    var that = this;
    return {
      title: '',
      path: '/pages/welcome/welcome',
      success: function (res) {
        // 转发成功  

        that.shareClick();
      },
      fail: function (res) {
        // 转发失败  
      }
    }
  },  
  singleDelete:function(e){
    var temp={};
    var index = wx.getStorageSync('index');
    var Index = e.currentTarget.id;
    wx.showModal({
      title: '提示',
      content: '确定要删除吗？',
      success: function (sm) {
        if (sm.confirm) {
          temp = wx.getStorageSync('sg');
          temp.splice(Index, 1);
          wx.setStorageSync('sg', temp);
          index--;
          wx.setStorageSync('index', index);
          wx.showToast({
            title: '已删除！',
            duration: 2000
          })
        } else if (sm.cancel) {
          wx.showToast({
            title: '已取消！',
            duration:2000
          })
        }
      }
    })
  }
 
})