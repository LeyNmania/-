Page({
  onTap: function (event) {
    wx.switchTab({
      url: '../general/general',
    })

  },
    
})